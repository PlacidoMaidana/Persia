<td class="no-sort no-click bread-actions">
    <a href="<?php echo e(url('/admin/movimientos_financieros/'.$id.'/egresos')); ?>" > <i class="voyager-search"></i>Editar: <?php echo e($detalle); ?> </a>
                                                                                                                                                                     
    <a href="javascript:;" title="Delete" class="btn btn-sm btn-danger pull-right delete pato" onclick="borrar(<?php echo e($id); ?>)" data-id="<?php echo e($id); ?>" id="delete-<?php echo e($id); ?>">
    <i class="voyager-trash"></i> <span class="hidden-xs hidden-sm">Delete</span>
    </a> 
                                       
</td>
<?php /**PATH C:\laragon\www\Persia\resources\views/vendor/voyager/movimientos_financieros/acciones_egresos.blade.php ENDPATH**/ ?>