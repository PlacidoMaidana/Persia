<a href="#" onclick="elegir_localidad(<?php echo e($id); ?>,'<?php echo e($provincia); ?>','<?php echo e($localidad); ?>')">
    <i class="voyager-check"></i> Seleccionar <?php echo e($id); ?></a>
   <?php /**PATH C:\xampp\htdocs\persia\resources\views/vendor\voyager\localidad\boton_seleccionar.blade.php ENDPATH**/ ?>