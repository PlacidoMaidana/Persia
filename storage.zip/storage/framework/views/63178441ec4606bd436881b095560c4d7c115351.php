
 <td class="no-sort no-click bread-actions">
<a href="<?php echo e(url('/admin/ordenes_fabricacion/'.$id_orden_fabricacion.'/edit')); ?>" > <i class="voyager-search"></i> <?php echo e($descripcion); ?> </a>
 
 

                                                    
                                                                                                                                            
<a href="<?php echo e(url('admin/ordenes_fabricacion/'.$id_orden_fabricacion.'/edit')); ?>" title="Edit" class="btn btn-sm btn-primary pull-right edit">
<i class="voyager-edit"></i> <span class="hidden-xs hidden-sm">Edit</span>
</a>
                                                    
    
                                             
</td><?php /**PATH C:\xampp\htdocs\persia\resources\views/vendor\voyager\ordenes_fabricacion\acciones_ordenes_fabricacion.blade.php ENDPATH**/ ?>