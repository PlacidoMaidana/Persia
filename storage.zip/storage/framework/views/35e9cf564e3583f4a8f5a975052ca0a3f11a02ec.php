<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    
    <style>
		table {
			border:1px solid #b3adad;
			border-collapse:collapse;
			padding:5px;
		}
		table th {
			border:1px solid #b3adad;
			padding:5px;
			background: #f0f0f0;
			color: #313030;
		}
		table td {
			border:1px solid #b3adad;
			text-align:center;
			padding:5px;
			background: #ffffff;
			color: #313030;
		}
	</style>

</head>
<body>
    
    

    <img class="img-responsive" 
    src="<?php echo e(public_path("images/cabeza.jpg")); ?>" width="70%" alt="">

    <h3>Fecha: <?php echo e($datosPedidos->fecha); ?> </h3> 
    <h3>Cliente: <?php echo e($datosPedidos->nombre); ?></h3> 
    <hr />
    
    Pedido Nro: <?php echo e($datosPedidos->id_pedido); ?> <br>
    Estado: <?php echo e($datosPedidos->estado); ?> <br>  
     

    <hr style="color: rgb(84, 83, 83); background-color: rgb(101, 100, 100); width:100% higth:2px ;" />

    <table class="table">
        <tbody>
            <thead >
                <tr>
                  <th scope="col">id producto</th>
                  <th scope="col">Descripcion</th>
                  <th scope="col">Cantidad</th>
                  <th scope="col">Total linea</th>
                </tr>
              </thead>
    <?php $__currentLoopData = $detallesPedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr >
        <td> <?php echo e($p->id_producto); ?></td>
        <td> <?php echo e($p->descripcion); ?></td>
        <td> <?php echo e($p->cantidad); ?></td>
        <td> <?php echo e($p->total_linea); ?></td>

    </tr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
    </table>
    <br>

    Total sin IVA: <?php echo e($datosPedidos->totalgravado); ?> <br>
    IVA: <?php echo e($datosPedidos->monto_iva); ?> <br>
    Descuento: <?php echo e($datosPedidos->descuento); ?> <br>
    Total general: <?php echo e($datosPedidos->total); ?> <br>
    <br>
    <hr />
    <br>
    Observaciones: <?php echo e($datosPedidos->observaciones); ?> <br>
    <br>
    <hr />
    <br>
    Forma pago: <?php echo e($texto->Forma_pago_Productos); ?> <br>

    <img class="img-responsive" 
    src="<?php echo e(public_path("images/cabeza.jpg")); ?>" width="70%" alt="">
</body>

</html><?php /**PATH C:\laragon\www\Persia\resources\views/vendor/voyager/nota-pedidos/exportar.blade.php ENDPATH**/ ?>