
    <input type="checkbox" name="row_id" id="checkbox_<?php echo e($id); ?>" value="<?php echo e($id); ?>">

    <?php /**PATH C:\laragon\www\Persia\resources\views/vendor/voyager/movimientos_financieros/check.blade.php ENDPATH**/ ?>