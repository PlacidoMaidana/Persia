
    <input type="checkbox" name="row_id" id="checkbox_<?php echo e($id_pedido); ?>" value="<?php echo e($id_pedido); ?>">

    

    <?php /**PATH C:\xampp\htdocs\Persia\resources\views/vendor/voyager/nota-pedidos/check_pedido.blade.php ENDPATH**/ ?>