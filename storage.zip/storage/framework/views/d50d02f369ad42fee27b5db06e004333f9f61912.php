
    <input type="checkbox" name="row_id" id="checkbox_<?php echo e($id_producto); ?>" value="<?php echo e($id_producto); ?>">

    

    <?php /**PATH C:\laragon\www\Persia\resources\views/vendor\voyager\productos\check_productos.blade.php ENDPATH**/ ?>