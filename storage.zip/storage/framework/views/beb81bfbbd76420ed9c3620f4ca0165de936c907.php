

<td class="no-sort no-click bread-actions">
<a href="<?php echo e(url('/admin/productos/'.$id_producto.'/editMP')); ?>" > <i class="voyager-search"></i>Editar: <?php echo e($descripcion); ?> </a>
                                                                                    
<a href="javascript:;" title="Delete" class="btn btn-sm btn-danger pull-right delete pato" onclick="borrar(<?php echo e($id_producto); ?>)" data-id="<?php echo e($id_producto); ?>" id="delete-<?php echo e($id_producto); ?>">
<i class="voyager-trash"></i> <span class="hidden-xs hidden-sm">Delete</span>
</a> 
 
                                             
</td><?php /**PATH C:\laragon\www\Persia\resources\views/vendor/voyager/productos/acciones_MP.blade.php ENDPATH**/ ?>