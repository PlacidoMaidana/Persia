<a href="#" onclick="elegir_rubro(<?php echo e($id_rubro); ?>,'<?php echo e($rubro); ?>','<?php echo e($id_subrubro); ?>','<?php echo e($descripcion_subrubro); ?>')">
    <i class="voyager-check"></i> Seleccionar <?php echo e($descripcion_subrubro); ?></a>
   <?php /**PATH C:\xampp\htdocs\persia\Persia\resources\views/vendor\voyager\rubros\boton_seleccionar.blade.php ENDPATH**/ ?>