
<a href="#" onclick="elegir(<?php echo e($id); ?>,'<?php echo e($descripcion); ?>')">
    <i class="voyager-check"></i> Seleccionar <?php echo e($id); ?></a>
<?php /**PATH C:\laragon\www\Persia\resources\views/vendor\voyager\productos\boton_seleccionar.blade.php ENDPATH**/ ?>