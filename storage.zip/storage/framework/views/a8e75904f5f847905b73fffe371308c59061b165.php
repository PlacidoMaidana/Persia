




<?php $__env->startSection('page_title', __('voyager::generic.viewing').' '.$dataType->getTranslatedAttribute('display_name_plural')); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="container-fluid">
        <h1 class="page-title">
            <i class="<?php echo e($dataType->icon); ?>"></i> <?php echo e($dataType->getTranslatedAttribute('display_name_plural')); ?>

        </h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add', app($dataType->model_name))): ?>
            <a href="<?php echo e(url('/admin/mov-financieros/create_cobranzas/'.$pedido)); ?> " class="btn btn-success btn-add-new">
                <i class="voyager-plus"></i> <span><?php echo e(__('voyager::generic.add_new')); ?></span>
            </a>
           
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', app($dataType->model_name))): ?>
            <?php echo $__env->make('voyager::partials.bulk-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <a id="operar" href="javascript:;" class="btn btn-danger delete"> Borrar seleccionados</a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', app($dataType->model_name))): ?>
            <?php if(!empty($dataType->order_column) && !empty($dataType->order_display_column)): ?>
               
                <a href="<?php echo e(route('voyager.'.$dataType->slug.'.order')); ?>" class="btn btn-primary btn-add-new">
                    <i class="voyager-list"></i> <span><?php echo e(__('voyager::bread.order')); ?></span>
                </a>
            <?php endif; ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', app($dataType->model_name))): ?>
            
        <?php endif; ?>
        
        <?php echo $__env->make('voyager::multilingual.language-selector', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content browse container-fluid">
        <?php echo $__env->make('voyager::alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    <div class="panel-body">
                                                  

                            


                            

                                <table id="cobranzas" class="table table-striped table-bordered dt-responsive "  >
                                    <thead>
                                      <tr >
                                          <th class="dt-not-orderable">
                                              <input type="checkbox" class="select_all">
                                          </th>
                                          <th>id</th>
                                          <th>fecha</th>
                                          <th>detalle</th>
                                          <th>importe ingreso</th>
                                          
                                          <th>accion</th>
                                        </tr>
                                    </thead>  
                                </table>
                            
                         
                        

<div class="card">
    <div class="card-body">
        <h5 class="card-title">Totales</h5>
        <p class="card-text">el total de todo</p>
    </div>
</div>


                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal modal-danger fade" tabindex="-1" id="delete_modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo e(__('voyager::generic.close')); ?>"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><i class="voyager-trash"></i> <?php echo e(__('voyager::generic.delete_question')); ?> <?php echo e(strtolower($dataType->getTranslatedAttribute('display_name_singular'))); ?>?</h4>
                </div>
                <div class="modal-footer">
                    <form action="#" id="delete_form" method="POST">
                        <?php echo e(method_field('DELETE')); ?>

                        <?php echo e(csrf_field()); ?>

                        <input type="submit" class="btn btn-danger pull-right delete-confirm" value="<?php echo e(__('voyager::generic.delete_confirm')); ?>">
                    </form>
                    <button type="button" class="btn btn-default pull-right" data-dismiss="modal"><?php echo e(__('voyager::generic.cancel')); ?></button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php if(!$dataType->server_side && config('dashboard.data_tables.responsive')): ?>
    <link rel="stylesheet" href="<?php echo e(voyager_asset('lib/css/responsive.dataTables.min.css')); ?>">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    


<script>
    $(document).ready(function() {
        $('#cobranzas').dataTable( {
             "serverSide": true,
             "ajax":"<?php echo e(url('/cobranzas_notapedido/'.$pedido)); ?>",                
             "columns":[
                     {data: 'check', width: '5%'},
                     {data: 'id', name: 'id', width: '5%'},
                     {data: 'fecha', name: 'fecha', width: '5%'},
                     {data: 'detalle', name: 'detalle', width: '10%'},
                     {data: 'importe_ingreso', name: 'importe_ingreso', width: '10%'},
                     {data: 'accion', width: '10%'},
                      ]           
        } );
    } );
</script> 





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.voyager2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Persia\resources\views/vendor/voyager/mov-financieros/cobranzas_pedido.blade.php ENDPATH**/ ?>