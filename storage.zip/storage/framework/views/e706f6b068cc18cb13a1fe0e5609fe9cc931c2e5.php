<div>
   
<?php
 //   dd($dataType);
?>

 <!-- Adding / Editing -->

 <div class="card">
    <img class="card-img-top" src="holder.js/100x180/" alt="">
    <div class="card-body">
        
        <?php $__currentLoopData = $dataTypeContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

             
            <?php if( ( $item->field=='created_at')||( $item->field=='updated_at')||( $item->field=='id')||( $item->field=='cliente_belongsto_localidade_relationship')||
                  ( $item->field=='registro_fce')||( $item->field=='cond_iva')||( $item->field=='cp')
                  ): ?>
                    <?php
                        continue;
                    ?>
            <?php else: ?> <?php if($item->field=='id_localidad'): ?>
                    <div class="form-group">
                        <label for="my-input">Localidad:
                            <div id="descripcion_localidad"></div>
                            <button type="button" id="localidad" class="btn btn-primary " style="width: 134px">
                                <div class="icon voyager-zoom-in">Localidad</div> 
                            </button>
                               
                        </label>
                    <input wire:model="<?php echo e($item->field); ?>" id="id_localidad" class="form-control" type="hidden" name="<?php echo e($item->field); ?>">
                     
                    </div>
                <?php else: ?>
                <div class="form-group">
                    <label for="my-input"><?php echo e($item->display_name); ?></label>
                    <input wire:model="<?php echo e($item->field); ?>" class="form-control" type="<?php echo e($item->type); ?>" name="<?php echo e($item->field); ?>">
                </div>
                <?php endif; ?>  
            
             <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <button type="button" wire:click="guardar" id="guardar_cliente"class="btn btn-primary">+ cliente </button>

         


    </div>
</div>



</div>




<?php /**PATH C:\xampp\htdocs\persia\resources\views/livewire/ficha-cliente.blade.php ENDPATH**/ ?>