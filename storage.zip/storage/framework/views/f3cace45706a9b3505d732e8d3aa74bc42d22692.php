<a href="#" onclick="elegir(<?php echo e($id); ?>,'<?php echo e($descripcion); ?>','<?php echo e($preciovta); ?>')">
    <i class="voyager-check"></i> Seleccionar <?php echo e($id); ?></a>
   <?php /**PATH C:\xampp\htdocs\Persia\resources\views/vendor\voyager\nota-pedidos\boton_seleccionar.blade.php ENDPATH**/ ?>