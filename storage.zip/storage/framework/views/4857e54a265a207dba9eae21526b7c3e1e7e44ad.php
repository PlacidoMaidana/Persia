

 

<div class="card">
  <div class="card-body">
    <h3 class="card-title"> Items</h3>
    <div class="row">
     
        <form class="row g-2">
          <div class="col-auto">
            <label for="">Producto</label>
            <input type="text" wire:model="producto" id="nombre_producto" class="form-control" placeholder="" aria-describedby="helpId" readonly>
            <small id="helpId" class="text-muted">Seleccione el producto de la lista</small>
       
          </div>
          <div class="col-auto">
            <button type="button" class="btn btn-primary" id="productos_buscar"
            data-bs-toggle="modal" data-bs-target="#productos">
            Productos
            </button>
          </div>
         </div>

        <div class="form-group col">
          <label for="">Cantidad</label>
          <input type="text" wire:model="cantidad" id="cantidad" class="form-control" placeholder="" aria-describedby="helpId">
          <small id="helpId" class="text-muted">Cantidad</small>
        </div>

        <div class="form-group col">
          <label for="">Precio</label>
          <input type="text" wire:model="precio" id="precio" class="form-control " 
          aria-describedby="helpId">
          <small id="helpId" class="text-muted">Precio</small>
        </div>

       


        <input type="hidden" wire:model="id_producto" id="id_producto" name="id_producto" >
        <input type="hidden" wire:model="total_general" id="total_general" name="total_general" >

        <input type="hidden" name="detalles_string" wire:model="detalles_string">
      
    </div>
    <div class="row ">
      <div class="col-md-4  ">
        <button  type="button" id="agregar" class="btn btn-sm btn-primary"
                 wire:click='addDetalles' >Agregar</button>
      </div>    
    </div>
    
     
    <table class="table">
      <thead>
        <tr>
          <th>id</th>
          <th>producto</th>
          <th>cantidad  </th>
          <th>precio</th>
          <th>detalle</th>
          <th>acciones</th>
        </tr>
      </thead>
      <tbody>
        
       <?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td scope="row"><?php echo e($item['id_producto']); ?></td>
          <td scope="row"><?php echo e($item['producto']); ?></td>
          <td><?php echo e($item['cantidad']); ?></td>
          <td><?php echo e(number_format($item['precio'], 2, '.', ',')); ?></td>
          <td><?php echo e(number_format($item['total-linea'], 2, '.', ',')); ?></td>
          <td><a wire:click.prevent="quitar(<?php echo e($index); ?>)"> Quitar</a></td>
        </tr>  
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
       
      </tbody>
    </table>
        total general: <?php echo e(number_format($total_general, 2, '.', ',')); ?>

      
  </div>
</div>



<script>
  function elegir(id,nom,precio)
  { 
   $('#productos').modal('hide');   
   Livewire.emit('actualiza', id, nom,precio);    
  
   }
</script>


<script>
  $(function () {
      $(".money").maskMoney({
          decimal: '.',
          thousands: ''
          //prefix : 'R$ '
      });
  });
</script>


 





  


  <?php /**PATH C:\xampp\htdocs\persia\resources\views/livewire/pedidos/embebido-component.blade.php ENDPATH**/ ?>