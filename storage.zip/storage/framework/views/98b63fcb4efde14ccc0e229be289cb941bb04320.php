
    <input type="checkbox" name="row_id" id="checkbox_<?php echo e($id_orden_fabricacion); ?>" value="<?php echo e($id_orden_fabricacion); ?>">

    

    <?php /**PATH C:\xampp\htdocs\Persia\resources\views/vendor\voyager\ordenes_fabricacion\check_ordenes_fabricacion.blade.php ENDPATH**/ ?>