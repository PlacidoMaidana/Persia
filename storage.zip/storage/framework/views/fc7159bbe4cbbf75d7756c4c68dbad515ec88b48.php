

<td class="no-sort no-click bread-actions">
    <a href="<?php echo e(url('/admin/movimientos_financieros/'.$id_movimiento.'/ingresos')); ?>" > <i class="voyager-search"></i>Editar: <?php echo e($detalle); ?> </a>
                                                                                        
    <a href="javascript:;" title="Delete" class="btn btn-sm btn-danger pull-right delete pato" onclick="borrar(<?php echo e($id_movimiento); ?>)" data-id="<?php echo e($id_movimiento); ?>" id="delete-<?php echo e($id_movimiento); ?>">
    <i class="voyager-trash"></i> <span class="hidden-xs hidden-sm">Delete</span>
    </a> 
                                       
</td>


<?php /**PATH C:\laragon\www\Persia\resources\views/vendor/voyager/movimientos_financieros/acciones.blade.php ENDPATH**/ ?>