
<?php echo e($datos); ?>

<table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:60%">
    <thead>
      <tr>
          <th>tipo_factura</th>
          <th>pto_venta</th>
          <th>nro_factura</th>
          <th>fecha</th>
          <th>cuit</th>
          <th>subtotal</th>
          <th>exento</th>
          <th>iva_10_5</th>
          <th>iva_21</th>
          <th>iva_27</th>
          <th>monto_perc_iibb</th>
          <th>monto_percepcion_iva</th>
          <th>monto_percep_ganancias</th>
          <th>otros_impuestos</th>
          <th>total_factura</th>

      </tr>
     </thead>
 
    </table>

    <script>
        $(document).ready(function() 
            $('#example').dataTable( 
                 "serverSide": true,
                 "ajax":"url('/informes/iva_compras')",                
                 "columns":[
                         data: 'tipo_factura', name:'facturas_compras.tipo_factura', width: '5px',
                         data: 'pto_venta', name: 'facturas_compras.pto_venta', width: '20px',
                         data: 'nro_factura', name: 'facturas_compras.nro_factura', width: '30px',
                         data: 'fecha', name: 'facturas_compras.fecha', width: '205px',
                         data: 'cuit', name: 'proveedores.cuit', width: '205px',
                         data: 'subtotal', name: 'facturas_compras.subtotal',width: '205px',
                         data: 'exento', name: 'facturas_compras.exento',width: '205px',
                         data: 'iva_10_5', name:'facturas_compras.iva_10_5',width: '205px',
                         data: 'iva_21', name:'facturas_compras.iva_21',width: '205px',
                         data: 'iva_27', name: 'facturas_compras.iva_27',width: '205px',
                         data: 'monto_perc_iibb', name: 'facturas_compras.monto_perc_iibb',width: '205px',
                         data: 'monto_percepcion_iva', name: 'facturas_compras.monto_percepcion_iva',width: '205px',
                         data: 'monto_percep_ganancias', name: 'facturas_compras.monto_percep_ganancias',width: '205px',
                         data: 'otros_impuestos', name: 'facturas_compras.otros_impuestos',width: '205px',
                         data: 'total_factura', name: 'facturas_compras.total_factura', width: '205px',
 //
                          ]           
             );
         );
    
    
     </script> <?php /**PATH C:\xampp\htdocs\persia\resources\views/Livewire/informes/iva_compra.blade.php ENDPATH**/ ?>